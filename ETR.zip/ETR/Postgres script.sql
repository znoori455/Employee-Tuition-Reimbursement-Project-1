
-------_EMPLOYEE TABLE------------------------------------------------------------------------------------
--drop table employee cascade;
create TABLE Employee
(
    EID serial NOT NULL,
    Username VARCHAR(50) NOT NULL,
    Pass VARCHAR(50) NOT NULL,
    name varchar(100) not null,
    new_email character(1) not null default 'f',
    Available_Reimbursement numeric(10, 2) not null,
    Awarded_Reimbursement numeric(10, 2) not null,
    Department varchar(100) not null,
    DS int not null,
    DH int not null,
    CONSTRAINT PK_Employee PRIMARY KEY  (EID)
);
ALTER TABLE Employee ADD CONSTRAINT FK_DirectSupervisor
    FOREIGN KEY (DS) REFERENCES Direct_Supervisor (DSID) ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE Employee ADD CONSTRAINT FK_DepartmentHead
    FOREIGN KEY (DH) REFERENCES Department_Head (DHID) ON DELETE NO ACTION ON UPDATE NO ACTION;
   
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('Test', 'ing', 'Zak', 600, 400, 'Training',2 , 1);
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('testing', 'testing', 'Jacob', 900, 100, 'Finance',3 , 4);
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('rtw', 'rtw', 'Gordon', 900, 100, 'Finance',5 , 3);
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('s', 's', 'Ruth', 450, 650, 'Finance',5 , 3);
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('t', 't', 'Ian', 450, 650, 'Finance',5 , 3);				
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('u', 'u', 'Melanie', 450, 650, 'Finance',5 , 3);
insert into Employee (username, pass, name, available_reimbursement, awarded_reimbursement, department, DS, DH) 
					values ('v', 'v', 'Amanda', 450, 650, 'Finance',5 , 3);


--------DS TABLE-------------------------------------------------------------------
--drop table direct_supervisor cascade;   
create TABLE Direct_Supervisor
(
    DSID serial NOT NULL,
    Username VARCHAR(50) NOT NULL,
    Pass VARCHAR(50) NOT NULL,
    name varchar(100) not null,    
    new_email character(1) not null default 'f',    
    Available_Reimbursement numeric(10, 2) not null,
    Awarded_Reimbursement numeric(10, 2) not null,
    Department varchar(100) not null,
    DH int not null,
    CONSTRAINT PK_Direct_Supervisor PRIMARY KEY (DSID)
);
ALTER TABLE Direct_Supervisor ADD CONSTRAINT FK_DepartmentHead
    FOREIGN KEY (DH) REFERENCES Department_Head (DHID) ON DELETE NO ACTION ON UPDATE NO ACTION;

insert into direct_supervisor (username, pass, name, available_reimbursement, awarded_reimbursement, department, dh) 
								values ('abc', 'abc', 'Olivia', 1000, 0, 'Training', 1);
insert into direct_supervisor (username, pass, name, available_reimbursement, awarded_reimbursement, department, dh) 
								values ('ds', 'ds', 'Natalie', 400, 600, 'Accounting', 3);
insert into direct_supervisor (username, pass, name, available_reimbursement, awarded_reimbursement, department, dh) 
								values ('et', 'et', 'Frank', 400, 600, 'Finance', 4);


-------------DH TABLE-----------------------------------------------------------------------------------------------
--drop table department_head cascade;   
create TABLE Department_Head
(
    DHID serial NOT NULL,
    Username VARCHAR(50) NOT NULL,
    Pass VARCHAR(50) NOT NULL,
    name varchar(100) not null,    
    new_email character(1) not null default 'f',     
    Available_Reimbursement numeric(10, 2) not null,
    Awarded_Reimbursement numeric(10, 2) not null,
    Department varchar(100) not null,
    CONSTRAINT PK_DepartmentHead PRIMARY KEY  (DHID)
);
insert into department_head (username, pass, name, available_reimbursement, awarded_reimbursement, department) 
						values ('Hello', 'World', 'Austin', 1000, 0, 'CEO');
insert into department_head (username, pass, name, available_reimbursement, awarded_reimbursement, department) 
						values ('aef', 'aef', 'David', 1000, 0, 'Food');
insert into department_head (username, pass, name, available_reimbursement, awarded_reimbursement, department) 
						values ('dh', 'dh', 'Mary', 1000, 0, 'Accounting');
insert into department_head (username, pass, name, available_reimbursement, awarded_reimbursement, department) 
						values ('der', 'der', 'Molly', 400, 600, 'Finance');

-------------BC TABLE----------------------------------------------------------------------------------------------------------------------
--drop table benefits_coordinator cascade;
create TABLE Benefits_Coordinator
(
    BID serial NOT NULL,
    Username VARCHAR(50) NOT NULL,
    Pass VARCHAR(50) NOT NULL,
    name varchar(100) not null,    
    new_email character(1) not null default 'f',         
    Available_Reimbursement numeric(10, 2) not null,
    Awarded_Reimbursement numeric(10, 2) not null,
    DS int,
    DH int,
    CONSTRAINT PK_BenefitsCoordinator PRIMARY KEY  (BID)
);
ALTER TABLE benefits_coordinator ADD CONSTRAINT FK_BencoSupervisor
    FOREIGN KEY (DS) REFERENCES benefits_coordinator (BID) ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE benefits_coordinator ADD CONSTRAINT FK_BencoHead
    FOREIGN KEY (DH) REFERENCES benefits_coordinator (BID) ON DELETE NO ACTION ON UPDATE NO ACTION;

insert into benefits_coordinator (username, pass, name, available_reimbursement, awarded_reimbursement) 
						values ('Bencho', 'DH', 'Tracey', 700, 0);
insert into benefits_coordinator (username, pass, name, available_reimbursement, awarded_reimbursement) 
						values ('benco', 'DS', 'Colin', 800, 200);
insert into benefits_coordinator (username, pass, name, available_reimbursement, awarded_reimbursement) 
						values ('benco', 'benco', 'Wendy', 600, 400);
					


----------GRADING FORMAT TABLE--------------------------------------------------------------------------------------------------
--drop table grading_format cascade;
create TABLE Grading_Format
(
    GFID serial NOT NULL,
    Format varchar(30) not null,
    CONSTRAINT PK_GradingFormat PRIMARY KEY  (GFID)
);
insert into grading_format (Format) values ('0-100');
insert into grading_format (Format) values ('A-F');
insert into grading_format (Format) values ('Presentation');


---------REQUEST TYPE TABLE---------------------------------------------------------------------------------------------------
--drop table request_type cascade;
create TABLE Request_Type
(
    RTID serial NOT NULL,
    Type varchar(50) not null,
    Coverage numeric(3, 2),
    CONSTRAINT PK_RequestType PRIMARY KEY  (RTID)
);
insert into Request_Type (Type, Coverage) values ('Certification', 1.00);
insert into Request_Type (Type, Coverage) values ('Technical Training', .90);
insert into Request_Type (Type, Coverage) values ('University Courses', .80);
insert into Request_Type (Type, Coverage) values ('Certification Preparation Classes', .75);
insert into Request_Type (Type, Coverage) values ('Seminars', .60);
insert into Request_Type (Type, Coverage) values ('Other', .30);



------------REQUEST TABLE------------------------------------------------------------------------------------------------
--drop table request cascade;
create TABLE Request
(
    RID serial NOT NULL,
    name VARCHAR(100) NOT NULL,
    start_time VARCHAR(100) NOT NULL,
    end_time VARCHAR(100) NOT NULL,
    descripton varchar(400) not null,
    justification varchar(400) not null,
    cost numeric(10, 2) not null,
    projected_reimbursement numeric(10, 2) not null,
    location varchar(100) not null,
    Department varchar(100) not null,
    escalation_level varchar(50) default 'Direct Supervisor',
    grading_cutoff varchar(50),
    RTID int not null,
    GFID int not null,
    EID int,
    DSID int,
    DHID int,
    BCID int,
    CONSTRAINT PK_Request PRIMARY KEY  (RID)
);
ALTER TABLE request ADD CONSTRAINT FK_Request_type
    FOREIGN KEY (RTID) REFERENCES Request_type (RTID) ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE request ADD CONSTRAINT FK_Grading_Format
    FOREIGN KEY (GFID) REFERENCES Grading_Format (GFID) ON DELETE NO ACTION ON UPDATE NO ACTION;  
ALTER TABLE request ADD CONSTRAINT FK_Empoyee_id
    FOREIGN KEY (EID) REFERENCES employee (EID) ON DELETE NO ACTION ON UPDATE NO ACTION;  


   
--drop table department_head cascade;
   
----------------------------------------------------------------------------------------
-------------FUNCTIONS----------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
----------LOGIN FUNCTION---------------------------------------------------------------------------------------------------------
create or replace function login(varchar, varchar)
returns varchar as $$
declare 
emp boolean;
ds boolean;
dh boolean;
benco boolean;
begin
	SELECT EXISTS(SELECT * FROM employee where username = $1 and pass = $2) into emp;
	SELECT EXISTS(SELECT * FROM direct_supervisor where username = $1 and pass = $2) into ds;
	SELECT EXISTS(SELECT * FROM department_head where username = $1 and pass = $2) into dh;
	SELECT EXISTS(SELECT * FROM benefits_coordinator where username = $1 and pass = $2) into benco;


	IF emp THEN
  		return 'Employee';
	elseif ds then
		return 'Direct Supervisor';
	elseif dh then
		return 'Department Head';
	elseif benco then
		return 'Benefits Coordinator';
	else
		return 'Invalid Login';
	END IF;

end
$$ language plpgsql;

do language plpgsql $$
declare





------------------------------------------------------------------------------------------------------------



------------get direct supervisor list-------------------------------------------------------
select r.rid, r.name, r.start_time, r.end_time, r.descripton, 
	r.justification, r.cost, r.projected_reimbursement, r.location, 
	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff
	from request r
		inner join request_type on r.rtid = request_type.rtid
		inner join grading_format on r.gfid = grading_format.gfid
		inner join employee on r.eid = employee.eid where employee.eid = 
				(select eid from employee where ds = 
					(select dsid from direct_supervisor where username = 'abc' and pass = 'abc'))
		and escalation_level = 'Pending Direct Supervisor Approval';
		
	and eid = (select eid from employee where ds = 
					(select dsid from direct_supervisor where username = 'abc' and pass = 'abc'))
	and escalation_level = 'Pending Direct Supervisor Approval';






------------get direct supervisor list----------------------------------------------------------------
select r.rid, r.name, r.start_time, r.end_time, r.descripton, 
	r.justification, r.cost, r.projected_reimbursement, r.location, 
	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff
	from request r
		inner join request_type on r.rtid = request_type.rtid
		inner join grading_format on r.gfid = grading_format.gfid
		inner join employee on r.eid = employee.eid where employee.eid in 
				(select eid from employee where ds = 
					(select dsid from direct_supervisor where username = 'abc' and pass = 'abc'))
		and escalation_level = 'Pending Direct Supervisor Approval';










-------------_Department Head List-------------------------------------------------------------------
select r.rid, r.name, r.start_time, r.end_time, r.descripton, 
	r.justification, r.cost, r.projected_reimbursement, r.location, 
	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff
	from request r
		inner join request_type on r.rtid = request_type.rtid
		inner join grading_format on r.gfid = grading_format.gfid
		inner join employee on r.eid = employee.eid where employee.eid in
				 (select eid from employee where dh = 
					(select dhid from department_head where username = 'Hello' and pass = 'World'))
		and escalation_level = 'Pending Department Head Approval'
union
select r.rid, r.name, r.start_time, r.end_time, r.descripton, 
	r.justification, r.cost, r.projected_reimbursement, r.location, 
	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff
	from request r
		inner join request_type on r.rtid = request_type.rtid
		inner join grading_format on r.gfid = grading_format.gfid
		inner join direct_supervisor on r.dsid = direct_supervisor.dsid where direct_supervisor.dsid in 
			(select dsid from direct_supervisor where dh = 
					(select dhid from department_head where username = 'Hello' and pass = 'World'))
		and escalation_level = 'Pending Department Head Approval';






				
				
---------__Benco list---------------------------------------------------------------------	-----------------------					
select r.rid, r.name, r.start_time, r.end_time, r.descripton, 
	r.justification, r.cost, r.projected_reimbursement, r.location, 
	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff
	from request r
		inner join request_type on r.rtid = request_type.rtid
		inner join grading_format on r.gfid = grading_format.gfid
		where  escalation_level = 'Pending Benefits Coordinator Approval'
		and bcid not in
			(select bid from benefits_coordinator where username = ? and pass = ?);	
				
				





--DROP FUNCTION personal_requests(character varying,character varying);








---DROP FUNCTION new_request(character varying,character varying,character varying,character varying,character varying,character varying,character varying,character varying,numeric,character varying,character varying,character varying,character varying);



----select new_request('Test', 'ing', 'Employee', 'Zak', '9/13 9:00AM', '3/4 19:00', 'something', 'else', 2000, 'tampa', 'Seminars', '0-100', '50');

		
		
		
		
		
-----------Puts a new request in the database-----------------------------------------------------------		
create or replace function new_request(usern varchar, passw varchar, status varchar, name varchar, 
											--$1				$2			$3				$4
										start_time varchar, end_time varchar, description varchar, justification varchar,
											--$5					$6					$7					$8
										cost numeric, location varchar,  req_type varchar, grading varchar, cutoff varchar)
											--$9				$10				$11					$12				$13
returns numeric as $$
declare 
empID int;
available numeric;
dept varchar;
projected numeric;
percent numeric;
reqID int;
gradeID int;
emp varchar = 'Employee';
ds varchar = 'Direct Supervisor';
dh varchar = 'Department Head';
benco varchar = 'Benefits Coordinator';
status varchar;

begin
	IF $3 = emp then
		select eid, available_reimbursement, department
			into empID, available, dept from employee where username = $1 and pass = $2;
		status = 'Pending Direct Supervisor Approval';
	elseif $3 = ds then
		select dsid, available_reimbursement, department
			into empID, available, dept from direct_supervisor where username = $1 and pass = $2;
		status = 'Pending Department Head Approval';
	elseif $3 = dh then
		select dhid, available_reimbursement, department
			into empID, available, dept from department_head where username = $1 and pass = $2;
		status = 'Pending Benefits Coordinator Approval';
	elseif $3 = benco then
		select bid, available_reimbursement
			into empID, available from benefits_coordinator where username = $1 and pass = $2;
		status = 'Pending Benefits Coordinator Approval';
	end if;
	
	select gfid from grading_format where format = $12 into gradeID;

	select coverage, rtid 
		into percent, reqID from request_type where type = $11;
	
	projected = $9 * percent;

	if projected > available then
		projected = available;
	end if;
--------down below inserting id into appropriate column depending on who is making the request
	IF $3 = emp then
	
		insert into request (name, start_time, end_time, descripton, justification, cost, projected_reimbursement, location, department, escalation_level, grading_cutoff, rtid, gfid, eid)
			 		values	($4,	$5,				$6,		$7,			$8,			  $9,		projected,				$10,	dept,		status,			      $13,    reqID, gradeID, empID);
			
	elseif $3 = ds then
	
		insert into request (name, start_time, end_time, descripton, justification, cost, projected_reimbursement, location, department, escalation_level, grading_cutoff, rtid, gfid, dsid)
					 values	($4,	$5,				$6,		$7,			$8,			  $9,		projected,				$10,	dept,		status,			      $13,    reqID, gradeID, empID);
				
	elseif $3 = dh then
	
		insert into request (name, start_time, end_time, descripton, justification, cost, projected_reimbursement, location, department, escalation_level, grading_cutoff, rtid, gfid, dhid)
					 values	($4,	$5,				$6,		$7,			$8,			  $9,		projected,				$10,	dept,		status,			      $13,    reqID, gradeID, empID);
				
	elseif $3 = benco then
	
		insert into request (name, start_time, end_time, descripton, justification, cost, projected_reimbursement, location, department, escalation_level, grading_cutoff, rtid, gfid, bcid)
					 values	($4,	$5,				$6,		$7,			$8,			  $9,		projected,				$10, 'Benefits',	status,			      $13,    reqID, gradeID, empID);
	end if;	
	return projected;
end
$$ language plpgsql;


-------------_APPROVEREQUEST----------------------------------------------------------------------------------------

select approve('abc', 'abc', (cast ('1' as integer)));



create or replace function approve(usern varchar, passw varchar, reqid int)
returns varchar as $$
declare 
ds boolean;
dh boolean;
benco boolean;
bool_verify int = 0;
exist boolean;
status varchar;
begin
	SELECT EXISTS(SELECT * FROM request where rid = $1) into exist;
	SELECT EXISTS(SELECT * FROM direct_supervisor where username = $1 and pass = $2) into ds;
	SELECT EXISTS(SELECT * FROM department_head where username = $1 and pass = $2) into dh;
	SELECT EXISTS(SELECT * FROM benefits_coordinator where username = $1 and pass = $2) into benco;


	IF ds then
		status := 'Pending Department Head Approval';
	elseif dh then
		status := 'Pending Benefits Coordinator Approval';
	elseif benco then
		status := 'Approved By All; Awaiting Completion';
	END IF;


	IF exist then
		update request set escalation_level = status;
		bool_verify = 1;
	END IF;

	return bool_verify;

end
$$ language plpgsql;


-------Gets list for a Direct Supervisor---------------------------------------
select r.rid, r.name, r.start_time, r.end_time, r.descripton, 
	r.justification, r.cost, r.projected_reimbursement, r.location, 
	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff
	from request r
		inner join request_type on r.rtid = request_type.rtid
		inner join grading_format on r.gfid = grading_format.gfid
		inner join employee on r.eid = employee.eid where employee.eid in 
				(select eid from employee where ds = 
					(select dsid from direct_supervisor where username = 'abc' and pass = 'abc'))
		and escalation_level = 'Pending Direct Supervisor Approval';






select r.rid, r.name, r.start_time, r.end_time, r.descripton,
		r.justification, r.cost, r.projected_reimbursement, r.location,
		r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff 
		from request r
			inner join request_type on r.rtid = request_type.rtid 
			inner join grading_format on r.gfid = grading_format.gfid
			inner join employee on r.eid = employee.eid where employee.eid in 
					(select eid from employee where ds = 
						(select dsid from direct_supervisor where username = 'ds and pass = 'ds'))
							and escalation_level = 'Pending Direct Supervisor Approval';

