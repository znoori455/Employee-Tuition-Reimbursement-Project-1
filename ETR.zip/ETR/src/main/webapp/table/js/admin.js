window.onload = () => {
    let accept = document.getElementById('accept');
    accept.addEventListener('click', update(e));
}

function update(e) {
    e.preventDefault;
    let rid = $('#rid').val();
    
    $.ajax({
	url: 'Approve',
	type: 'POST',
	data: JSON.stringify(rid)
    success: (response) => {
        alert(response);
    }
    });
    
//    $.ajax({
//	url: 'Approve',
//	type: 'POST',
//	success: (response) => {
//        alert(response);
//    }
//    });
}



window.onload = () => {
    $.get("AdminServlet", (text) => {
        console.log(text);
        let list = JSON.parse(text)
        addToTable(list);
    });
}





function addToTable(list) {
    for(let i = 0; i<list.length; i++) {
        addrow(list[i]);
    }
}



function addrow(i) {
let table = document.querySelector('tbody');
let row = document.createElement('tr');
row.className = 'row100';
table.appendChild(row);

let data1 = document.createElement('td');
data1.className = 'column100 column1';
let name1 = document.createAttribute('name');
name1.value = 'rid';
data1.setAttributeNode(name1);
data1.innerText = i.rid;
row.appendChild(data1);

let data2 = document.createElement('td');
data2.className = 'column100 column2';
let name2 = document.createAttribute('name');
name2.value = 'name';
data2.setAttributeNode(name2);
data2.innerText = i.name;
row.appendChild(data2);

let data3 = document.createElement('td');
data3.className = 'column100 column3';
let name3 = document.createAttribute('name');
name3.value = 'time';
data3.setAttributeNode(name3);
data3.innerText = i.startEnd;
row.appendChild(data3);

let data4 = document.createElement('td');
data4.className = 'column100 column4';
let name4 = document.createAttribute('name');
name4.value = 'description';
data4.setAttributeNode(name4);
data4.innerText = i.description;
row.appendChild(data4);

let data5 = document.createElement('td');
data5.className = 'column100 column5';
let name5 = document.createAttribute('name');
name5.value = 'justification';
data5.setAttributeNode(name5);
data5.innerText = i.justification;
row.appendChild(data5);

let data6 = document.createElement('td');
data6.className = 'column100 column6';
let name6 = document.createAttribute('name');
name6.value = 'cost';
data6.setAttributeNode(name6);
data6.innerText = i.cost;
row.appendChild(data6);

let data7 = document.createElement('td');
data7.className = 'column100 column7';
let name7 = document.createAttribute('name');
name7.value = 'covered';
data7.setAttributeNode(name7);
data7.innerText = i.coveredCost;
row.appendChild(data7);

let data8 = document.createElement('td');
data8.className = 'column100 column8';
let name8 = document.createAttribute('name');
name8.value = 'location';
data8.setAttributeNode(name8);
data8.innerText = i.location;
row.appendChild(data8);

let data9 = document.createElement('td');
data9.className = 'column100 column9';
let name9 = document.createAttribute('name');
name9.value = 'status';
data9.setAttributeNode(name9);
data9.innerText = i.status;
row.appendChild(data9);

let data10 = document.createElement('td');
data10.className = 'column100 column10';
let name10 = document.createAttribute('name');
name10.value = 'type';
data10.setAttributeNode(name10);
data10.innerText = i.type;
row.appendChild(data10);

let data11 = document.createElement('td');
data11.className = 'column100 column11';
let name11 = document.createAttribute('name');
name11.value = 'format';
data11.setAttributeNode(name11);
data11.innerText = i.gradingformat;
row.appendChild(data11);

let data12 = document.createElement('td');
data12.className = 'column100 column12';
let name12 = document.createAttribute('name');
name12.value = 'passing';
data12.setAttributeNode(name12);
data12.innerText = i.gradecutoff;
row.appendChild(data12);

}