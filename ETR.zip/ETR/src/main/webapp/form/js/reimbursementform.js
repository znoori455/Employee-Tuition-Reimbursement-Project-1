window.onload = () => {
    let form = document.getElementById('form');
    form.addEventListener('submit', save(e));
}

function save(e) {
    e.preventDefault;
    
    let format = $('[type="radio"]:checked')[0].id
    
    let request = {
	name : $('#first').val() + ' ' + $('#last').val(),
    startend: $('#startend').val(),
	description: $('#description').val(),
	justification: $('#justification').val(),
	cost: $('#cost').val(),
	location: $('#location').val(),
	type: $('#type').val(),
    gradingformat: format,
    gradecutoff: $('#cutoff').val()
    };
    
    
    send(request);
    
    
}

function send(request) {
    $.ajax({
	url: 'FormServlet',
	type: 'POST',
	data: JSON.stringify(request.name)
    });
}

let function apples() {
    
}

let request = {
	name : $('#first').val() + ' ' + $('#last').val(),
    startend: $('#startend').val(),
	description: $('#description').val(),
	justification: $('#justification').val(),
	cost: $('#cost').val(),
	location: $('#location').val(),
	type: $('#type').val(),
    gradingformat: a = $('[type="radio"]:checked')[0].id
};