package com.noori.daos;

public interface DHDao {

}
