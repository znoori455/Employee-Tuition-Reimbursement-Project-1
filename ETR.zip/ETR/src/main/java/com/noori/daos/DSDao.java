package com.noori.daos;

public interface DSDao {

}
