package com.noori.daos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.noori.pojos.BenCo;
import com.noori.pojos.DepartmentHead;
import com.noori.pojos.DirectSupervisor;
import com.noori.pojos.Employee;
import com.noori.pojos.Request;
import com.noori.utils.ConnectionFactory;

public class RequestDaoImpl implements RequestDao {
	private static Connection conn = ConnectionFactory.getConnection();


	@Override
	public Double makeNewRequest(Employee emp, Request req) {
		try {
			String sql = "{call new_request(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
			CallableStatement call = conn.prepareCall(sql);
			call.setString(1, emp.getUsername());
			call.setString(2, emp.getPassword());
			call.setString(3, emp.getType());
			call.setString(4, req.getName());
			call.setString(5, req.getStartTime());
			call.setString(6, req.getEndTime());
			call.setString(7, req.getDescription());
			call.setString(8, req.getJustification());
			call.setBigDecimal(9, req.getCost());
			call.setString(10, req.getLocation());
			call.setString(11, req.getType());
			call.setString(12, req.getGradingformat());
			call.setString(13, req.getGradecutoff());

			
			ResultSet rs = call.executeQuery();
			rs.next();
			double projectedReimbursement = rs.getDouble(1);
			System.out.println(projectedReimbursement);
			return projectedReimbursement;
			
		} catch (SQLException e) {
			System.out.println(e);
		}
		return null;
	}
	
	
	
	@Override
	public int approveRequest(Employee emp, int rid) {
		int boolInt = 0;
		try {
			String sql = "{call approve(?, ?, ?)}";
			CallableStatement call = conn.prepareCall(sql);
			call.setString(1, emp.getUsername());
			call.setString(2, emp.getPassword());
			call.setInt(3, rid);
			ResultSet rs = call.executeQuery();
			rs.next();
			boolInt = rs.getInt(1);
			System.out.println(" dsf" + boolInt);
			return boolInt;
		} catch (SQLException e) {
			System.out.println(e);
		}
		return boolInt;
	}

	
	
	
	
	@Override
	public List<Request> getPersonalRequestsMade(Employee emp, String sql) {
		List<Request> list = new ArrayList<Request>();
		
//			String sql = "select request.rid, request.name, request.start_time, request.end_time, request.descripton," + 
//					" request.justification, request.cost, request.projected_reimbursement, request.location, " + 
//					"	request.escalation_level, request_type.type, grading_format.format, request.grading_cutoff" + 
//					"	from request " + 
//					"		inner join request_type on request.rtid = request_type.rtid" + 
//					"		inner join grading_format on request.gfid = grading_format.gfid" +
//					"	and eid = (select eid from employee where username = ? and pass = ?);";
//			
//			
//			
//			switch (emp.getType()) {
//			case "Employee":
//				System.out.println("yes this is");
//				sql = sql + "	and eid = (select eid from employee where username = ? and pass = ?);";
//				
//				break;
//			case "Direct Supervisor":
//				sql += "	and dsid = (select dsid from direct_supervisor where username = ? and pass = ?);";
//				
//				break;
//			case "Department Head" :
//				sql = sql + "	and dhid = (select dhid from department_head where username = ? and pass = ?);";
//				
//				break;
//			case "Benefits Coordinator" :
//				sql += "	and bcid = (select bid from benefits_coordinator where username = ? and pass = ?);";
//				
//				break;
//			default:
//				break;
//			}
		try {	
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, emp.getUsername());
			pstmt.setString(2, emp.getPassword());
			System.out.println("hi");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Request r = new Request(rs.getInt(1), rs.getString(2), (rs.getString(3) +" - "+ rs.getString(4)), 
						rs.getString(5), rs.getString(6), rs.getBigDecimal(7), rs.getBigDecimal(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13));
				list.add(r);				
			}
			System.out.println(list);
		} catch (SQLException e) {
			System.out.println(e);
		}
		System.out.println("bye");
		System.out.println(list);
		return list;
	}


	
	
	
	@Override
	public List<Request> getDSRequests(Employee dS) {
		List<Request> list = new ArrayList<Request>();
		try {
			String sql = "select r.rid, r.name, r.start_time, r.end_time, r.descripton, \n" + 
					"	r.justification, r.cost, r.projected_reimbursement, r.location, \n" + 
					"	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff\n" + 
					"	from request r\n" + 
					"		inner join request_type on r.rtid = request_type.rtid\n" + 
					"		inner join grading_format on r.gfid = grading_format.gfid\n" + 
					"		inner join employee on r.eid = employee.eid where employee.eid in \n" + 
					"				(select eid from employee where ds = \n" + 
					"					(select dsid from direct_supervisor where username = ? and pass = ?))\n" + 
					"		and escalation_level = 'Pending Direct Supervisor Approval';";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dS.getUsername());
			pstmt.setString(2, dS.getPassword());
			ResultSet rs = pstmt.executeQuery();
			Request r;
			while (rs.next()) {
				r = new Request(rs.getInt(1), rs.getString(2), (rs.getString(3) +" - "+ rs.getString(4)), 
						rs.getString(5), rs.getString(6), rs.getBigDecimal(7), rs.getBigDecimal(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13));
				System.out.println(r);
				list.add(r);		
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		
		System.out.println(list);
		return list;
	}

	
	
	
	
	@Override
	public List<Request> getDHRequests(Employee dH) {
		List<Request> list = new ArrayList<Request>();
		try {
			
					
			String sql = "(select r.rid, r.name, r.start_time, r.end_time, r.descripton, " + 
					"	r.justification, r.cost, r.projected_reimbursement, r.location, " + 
					"	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff " + 
					"	from request r " + 
					"		inner join request_type on r.rtid = request_type.rtid " + 
					"		inner join grading_format on r.gfid = grading_format.gfid " + 
					"		inner join employee on r.eid = employee.eid where employee.eid in " + 
					"				 (select eid from employee where dh = " + 
					"					(select dhid from department_head where username = 'Hello' and pass = 'World')) " + 
					"		and escalation_level = 'Pending Department Head Approval' " + 
					"union " + 
					"select r.rid, r.name, r.start_time, r.end_time, r.descripton, " + 
					"	r.justification, r.cost, r.projected_reimbursement, r.location, " + 
					"	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff" + 
					"	from request r" + 
					"		inner join request_type on r.rtid = request_type.rtid" + 
					"		inner join grading_format on r.gfid = grading_format.gfid" + 
					"		inner join direct_supervisor on r.dsid = direct_supervisor.dsid where direct_supervisor.dsid in " + 
					"			(select dsid from direct_supervisor where dh = " + 
					"					(select dhid from department_head where username = 'Hello' and pass = 'World'))" + 
					"		and escalation_level = 'Pending Department Head Approval';)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dH.getUsername());
			pstmt.setString(2, dH.getPassword());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Request r = new Request(rs.getInt(1), rs.getString(2), (rs.getString(3) +" - "+ rs.getString(4)), 
						rs.getString(5), rs.getString(6), rs.getBigDecimal(7), rs.getBigDecimal(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13));
				list.add(r);		
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		
		System.out.println(list);
		return list;
	}

	@Override
	public List<Request> getBCRequests(Employee bC) {
		List<Request> list = new ArrayList<Request>();
		try {
			String sql = "select r.rid, r.name, r.start_time, r.end_time, r.descripton, " + 
					"	r.justification, r.cost, r.projected_reimbursement, r.location, " + 
					"	r.escalation_level, request_type.type, grading_format.format, r.grading_cutoff" + 
					"	from request r" + 
					"		inner join request_type on r.rtid = request_type.rtid" + 
					"		inner join grading_format on r.gfid = grading_format.gfid" + 
					"		where  escalation_level = 'Pending Benefits Coordinator Approval'" + 
					"		and bcid not in" + 
					"			(select bid from benefits_coordinator where username = '1234' and pass = '2421');";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bC.getUsername());
			pstmt.setString(2, bC.getPassword());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Request r = new Request(rs.getInt(1), rs.getString(2), (rs.getString(3) +" - "+ rs.getString(4)), 
						rs.getString(5), rs.getString(6), rs.getBigDecimal(7), rs.getBigDecimal(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13));
				list.add(r);		
			}
		} catch (SQLException e) {
			System.out.println(e);
		}

		System.out.println(list);
		return list;
	}





}
