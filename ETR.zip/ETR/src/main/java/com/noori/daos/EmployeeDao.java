package com.noori.daos;

import java.util.List;

import com.noori.pojos.Employee;


public interface EmployeeDao {
	
	public Employee login(String username, String password);
	//select * from employee where ? and ?;
	//check rank column in employee table (Employee, DS, DH, BenCo)
	//switch rank
		//case rank= "employee" ; make a new employee and direct to employee page
		//case rank= "DS" ; make a new DS and direct to DS page
		//...
	
	
	public List<Employee> getAllEmployees();
	

}
