package com.noori.daos;

public interface BenCoDao {

}
