package com.noori.daos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.noori.pojos.BenCo;
import com.noori.pojos.DepartmentHead;
import com.noori.pojos.DirectSupervisor;
import com.noori.pojos.Employee;
import com.noori.utils.ConnectionFactory;

public class EmployeeDaoImpl implements EmployeeDao {

	private static Connection conn = ConnectionFactory.getConnection();


	@Override
	public Employee login(String username, String password) {
		try {
			
			String sql = "{call login(?, ?)}";
			CallableStatement call = conn.prepareCall(sql);
			call.setString(1, username);
			call.setString(2, password);
			
			ResultSet rs = call.executeQuery();
			rs.next();
			String typeOfEmployee = rs.getString(1);
			System.out.println(typeOfEmployee);
			
			switch (typeOfEmployee) {
			
			case "Employee":	
				System.out.println("table accessed");
				EmployeeDaoImpl edi = new EmployeeDaoImpl();
				return edi.getEmployee(username, password);
			
			case "Direct Supervisor":
				DSDaoImpl dsdi = new DSDaoImpl();
				return dsdi.getDirectSupervisor(username, password);
			
			case "Department Head":
				DHDaoImpl dhdi = new DHDaoImpl();
				return dhdi.getDepartmentHead(username, password);
			
			case "Benefits Coordinator":
				BenCoDaoImpl bcdi = new BenCoDaoImpl();
				return bcdi.getBenCo(username, password);
			
			case "invalid login":
				return null;
			default:
				break;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	public Employee getEmployee(String username, String password) {
		try {
			PreparedStatement pstmt = conn.prepareStatement("select * from employee where username = ? and pass = ?;");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			Employee emp = new Employee(username, password, rs.getString("new_email"), rs.getDouble("available_reimbursement"));
			return emp;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

}
