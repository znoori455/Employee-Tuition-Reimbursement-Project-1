package com.noori.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.noori.pojos.DepartmentHead;
import com.noori.pojos.DirectSupervisor;
import com.noori.utils.ConnectionFactory;

public class DHDaoImpl implements DHDao {
	
	private static Connection conn = ConnectionFactory.getConnection();
	
	public DepartmentHead getDepartmentHead(String username, String password) {
		try {
			PreparedStatement pstmt = conn.prepareStatement("select * from department_head where username = ? and pass = ?;");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			DepartmentHead dh = new DepartmentHead(username, password, rs.getString("new_email"), rs.getDouble("available_reimbursement"));
			return dh;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}


}
