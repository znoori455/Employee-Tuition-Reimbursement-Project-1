package com.noori.daos;

import java.util.List;

import com.noori.pojos.Email;
import com.noori.pojos.Employee;

public interface EmailDao {
	
	public List<Email> getEmails(Employee emp);
	//select * from email where EmpID =
		 //select EmpID from Employee where ? and ?
	
	public List<Email> getNewEmails(Employee emp);
	//select * from email where new = true and EmpID =
	 	//select EmpID from Employee where ? and ?
	//set new flag to false

}
