package com.noori.daos;

import java.util.List;

import com.noori.pojos.BenCo;
import com.noori.pojos.DepartmentHead;
import com.noori.pojos.DirectSupervisor;
import com.noori.pojos.Employee;
import com.noori.pojos.Request;

public interface RequestDao {
	
	public Double makeNewRequest(Employee emp, Request req);
	//inserts a new request into the Request table
	
	public List<Request> getPersonalRequestsMade(Employee emp, String sql);
	//select* from Request where Employee = 
		//select * from Employee where ? and ?; user/password
	
	public List<Request> getDSRequests(Employee dS);
	//select* from Request where EmpId = 
		//select EmpId from Employee where DSID =
			//select * from DS where ? and ?; user/password
	
	public List<Request> getDHRequests(Employee dH);
	//select* from Request where EmpId = 
			//select EmpId from Employee where DHID =
				//select * from DH where ? and ?; user/password
	
	public List<Request> getBCRequests(Employee bC);
	//select* from Request where EmpId = 
		//select EmpId from Employee where BCID =
			//select * from BC where ? and ?; user/password
	
	public int approveRequest(Employee emp, int rid);


}
