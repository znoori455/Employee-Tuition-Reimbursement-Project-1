package com.noori.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.noori.pojos.DirectSupervisor;
import com.noori.pojos.Employee;
import com.noori.utils.ConnectionFactory;

public class DSDaoImpl implements DSDao {
	
	private static Connection conn = ConnectionFactory.getConnection();
	
	public DirectSupervisor getDirectSupervisor(String username, String password) {
		try {
			PreparedStatement pstmt = conn.prepareStatement("select * from direct_supervisor where username = ? and pass = ?;");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			DirectSupervisor ds = new DirectSupervisor(username, password, rs.getString("new_email"), rs.getDouble("available_reimbursement"));
			return ds;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
