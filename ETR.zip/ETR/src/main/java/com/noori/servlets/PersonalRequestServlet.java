package com.noori.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;

import com.noori.pojos.Employee;
import com.noori.pojos.Request;
import com.noori.services.RequestService;

@WebServlet("/PersonalServlet")
public class PersonalRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	int i = 0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PersonalRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession sess = req.getSession(false);
		Employee emp = (Employee) sess.getAttribute("employee");
		RequestService rs = new RequestService();
		List<Request> requests = rs.personalRequests(emp);
		System.out.println(requests);
		ObjectMapper om = new ObjectMapper();
		String list = om.writeValueAsString(requests);
		System.out.println(list);
		resp.getWriter().write(list);
		
	//	resp.sendRedirect("table.html");
//		RequestDispatcher rd = req.getRequestDispatcher("table.html");
//		rd.forward(req, resp);
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		doGet(req, resp);
	}

}
