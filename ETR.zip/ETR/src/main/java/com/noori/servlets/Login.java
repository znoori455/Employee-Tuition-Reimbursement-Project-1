package com.noori.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.noori.daos.EmployeeDaoImpl;
import com.noori.pojos.Employee;

@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Login() {
        super();
    }


	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("index.html");
		rd.forward(req, resp);

//		String username = req.getParameter("username");
//		String password = req.getParameter("pass");
//		EmployeeDaoImpl eDao = new EmployeeDaoImpl();
//		eDao.login(username, password);
//		resp.sendRedirect("/showAlien.html");
//		
		
	}


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String username = req.getParameter("username");
		String password = req.getParameter("pass");

		
		EmployeeDaoImpl eDao = new EmployeeDaoImpl();
		Employee emp = eDao.login(username, password);
		
		
		if (emp == null) {
			resp.setStatus(401);
			resp.getWriter().write("Failed Login");
		} else {
			HttpSession sess = req.getSession(true);
			sess.setAttribute("employee", emp);
			RequestDispatcher rd = req.getRequestDispatcher(emp.getWelcomeScreen());
			rd.forward(req, resp);
		}
		
		
//		resp.sendRedirect("LoginServlet");
//		RequestDispatcher rd = req.getRequestDispatcher("form.html");
//		rd.forward(req, resp);
		//doGet(req, resp);
	}

}
