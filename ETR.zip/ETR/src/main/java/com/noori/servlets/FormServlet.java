package com.noori.servlets;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;

import com.noori.pojos.Employee;
import com.noori.pojos.Request;
import com.noori.pojos.Request2;
import com.noori.services.RequestService;



@WebServlet("/FormServlet")
public class FormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public FormServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("form.html");
		rd.forward(request, response);



		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession sess = req.getSession(false);
		Employee emp = (Employee) sess.getAttribute("employee");
		
		System.out.println("made it");
		String name = (req.getParameter("firstname") + " " + req.getParameter("lastname"));
		
		String dateTimes = req.getParameter("datetimes");
		dateTimes = dateTimes.replaceAll(" - ", "-");
		String startTime = dateTimes.substring(0, dateTimes.indexOf("-"));
		String endTime = dateTimes.substring(dateTimes.indexOf("-")+ 1);
		
		String description = req.getParameter("description");
		String justification = req.getParameter("justification");
		Double temp = Double.parseDouble(req.getParameter("cost"));
		BigDecimal cost = BigDecimal.valueOf(temp);
		String location = req.getParameter("location");
		String type = req.getParameter("type");
		String gradingformat = req.getParameter("gradingformat");
		String gradecutoff = req.getParameter("gradecutoff");
		System.out.println(emp.getUsername());
		System.out.println(emp.getPassword());
		System.out.println(emp.getType());

		Request form = new Request(name, startTime, endTime, description, justification, cost, location, type, gradingformat, gradecutoff);
		System.out.println(form.getName());
		System.out.println();
		System.out.println(form.getCost());
		System.out.println();
		RequestService rs = new RequestService();
		double projectedReimbursement = rs.newForm(emp, form);
		System.out.println(projectedReimbursement);
		
		RequestDispatcher rd = req.getRequestDispatcher(emp.getWelcomeScreen());
		rd.forward(req, resp);
		
// 		String json = req.getReader().readLine();
//		System.out.println(json);
//		ObjectMapper mapper = new ObjectMapper();
//		json.substrin
//
//			Request2 form = mapper.readValue(json, Request2.class);


//		System.out.println(req.getReader().readLine());
		
		//RequestDispatcher rd = request.getRequestDispatcher("index.html");
		//rd.forward(request, response);
		//doGet(request, response);
	}

}
