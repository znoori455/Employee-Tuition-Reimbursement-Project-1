package com.noori.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.noori.pojos.Employee;
import com.noori.services.RequestService;

@WebServlet("/Approve")
public class ApproveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public ApproveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	}


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession sess = req.getSession(false);
		Employee emp = (Employee) sess.getAttribute("employee");
		String id = req.getParameter("rid");
		int rid = Integer.parseInt(id);
		
		RequestService rs = new RequestService();
		int boolInt = rs.approve(emp, rid);
		
		
		
		
		if (boolInt == 1)
			resp.getWriter().write("Request Approved Successfully.");
		else {
			resp.getWriter().write("Error! Request was not approved");
		}
		
		//doGet(req, resp);
	}

}
