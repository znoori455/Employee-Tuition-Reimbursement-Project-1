package com.noori.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.noori.daos.AlienDao;
import com.noori.pojos.Alien;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginServlet() {
        super();
    }


	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
//		int aid = Integer.parseInt(request.getParameter("aid"));
//		
//		AlienDao dao = new AlienDao();
//		Alien a1 = new Alien();
//		
//		request.setAttribute("alien", a1);
		RequestDispatcher rd = req.getRequestDispatcher("form.html");
		rd.forward(req, resp);
////		
//		RequestDispatcher rd = request.getRequestDispatcher("showAlien.html");
//		rd.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int aid = Integer.parseInt(request.getParameter("aid"));
		
		AlienDao dao = new AlienDao();
		Alien a1 = new Alien();
		
		request.setAttribute("alien", a1);
		
//		RequestDispatcher rd = request.getRequestDispatcher("showAlien.html");
//		rd.forward(request, response);
	}

}
