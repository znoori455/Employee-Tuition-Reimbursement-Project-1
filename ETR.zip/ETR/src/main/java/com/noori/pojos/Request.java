package com.noori.pojos;

import java.math.BigDecimal;

public class Request {
	//firstname=Zak&lastname=Noori&datetimes=7%2F03+11%3A00+PM+-+7%2F05+07%3A00+AM&description=whatever&justification=because+i+said+so&cost=400&location=tampa&type=University+Courses&gradingformat=A-F&gradecutoff=D

//	private String firstname;
//	private String lastname;
	private int rid;
	private String name;
//	private String datetimes;
	private String startEnd;
	private String startTime;
	private String endTime;
	private String description;
	private String justification;
	private BigDecimal cost;
	private BigDecimal coveredCost;
	private String location;
	private String status;
	private String type;
	private String gradingformat;
	private String gradecutoff;
	
	

	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartEnd() {
		return startEnd;
	}
	public void setStartEnd(String startEnd) {
		this.startEnd = startEnd;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getJustification() {
		return justification;
	}
	public void setJustification(String justification) {
		this.justification = justification;
	}
	public BigDecimal getCost() {
		return cost;
	}
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}
	public BigDecimal getCoveredCost() {
		return coveredCost;
	}
	public void setCoveredCost(BigDecimal coveredCost) {
		this.coveredCost = coveredCost;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGradingformat() {
		return gradingformat;
	}
	public void setGradingformat(String gradingformat) {
		this.gradingformat = gradingformat;
	}
	public String getGradecutoff() {
		return gradecutoff;
	}
	public void setGradecutoff(String gradecutoff) {
		this.gradecutoff = gradecutoff;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public Request(String name, String startTime, String endTime, String description, String justification,
			BigDecimal cost, String location, String type, String gradingformat, String gradecutoff) {
		super();
		this.name = name;
		this.startTime = startTime;
		this.endTime = endTime;
		this.description = description;
		this.justification = justification;
		this.cost = cost;
		this.location = location;
		this.type = type;
		this.gradingformat = gradingformat;
		this.gradecutoff = gradecutoff;
	}
	
	
	public Request(int rid, String name, String startEnd, String description, String justification, BigDecimal cost,
			BigDecimal coveredCost, String location, String status, String type, String gradingformat,
			String gradecutoff) {
		super();
		this.rid = rid;
		this.name = name;
		this.startEnd = startEnd;
		this.description = description;
		this.justification = justification;
		this.cost = cost;
		this.coveredCost = coveredCost;
		this.location = location;
		this.status = status;
		this.type = type;
		this.gradingformat = gradingformat;
		this.gradecutoff = gradecutoff;
	}

	
	
	
	

	
	
	
	
}
