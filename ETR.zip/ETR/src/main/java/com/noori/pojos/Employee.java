package com.noori.pojos;

import java.util.List;



public class Employee {
	
	private String username;
	private String password;
	private String welcomeScreen = "employeeWelcome.html";
	private String type = "Employee";
	private Double availableReimbursement;
	private DirectSupervisor dS;
	private DepartmentHead dH;
	private BenCo bC;
	private String newEmail;
	private List<Email> emails;
	private List<Request> requests;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Double getAvailableReimbursement() {
		return availableReimbursement;
	}
	public void setAvailableReimbursement(Double availableReimbursement) {
		this.availableReimbursement = availableReimbursement;
	}
	public String getNewEmail() {
		return newEmail;
	}
	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}
	public String getWelcomeScreen() {
		return welcomeScreen;
	}
	public void setWelcomeScreen(String welcomeScreen) {
		this.welcomeScreen = welcomeScreen;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	public Employee(String username, String password, String newEmail, Double availableReimbursement) {
		super();
		this.username = username;
		this.password = password;
		this.newEmail = newEmail;
		this.availableReimbursement = availableReimbursement;
	}
	public Employee(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public Employee() {
	}
	

}
