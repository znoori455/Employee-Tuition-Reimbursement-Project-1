package com.noori.pojos;

public class Email {

}
