package com.noori.pojos;

public class BenCo extends Employee {

	public BenCo(String username, String password, String newEmail, Double availableReimbursement) {
		super(username, password, newEmail, availableReimbursement);
		this.setWelcomeScreen("adminWelcome.html");
		this.setType("Benefits Coordinator");

	}
	
	

}
