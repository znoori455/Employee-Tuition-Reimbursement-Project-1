package com.noori.pojos;

public class Request2 {
	
	private String name;
	private String startend;
	private String description;
	private String justification;
	private Double cost;
	private String location;
	private String type;
	private String gradingformat;
	private String gradecutoff;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartend() {
		return startend;
	}
	public void setStartend(String startend) {
		this.startend = startend;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getJustification() {
		return justification;
	}
	public void setJustification(String justification) {
		this.justification = justification;
	}
	public Double getCost() {
		return cost;
	}
	public void setCost(Double cost) {
		this.cost = cost;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGradingformat() {
		return gradingformat;
	}
	public void setGradingformat(String gradingformat) {
		this.gradingformat = gradingformat;
	}
	public String getGradecutoff() {
		return gradecutoff;
	}
	public void setGradecutoff(String gradecutoff) {
		this.gradecutoff = gradecutoff;
	}

	
	
}
