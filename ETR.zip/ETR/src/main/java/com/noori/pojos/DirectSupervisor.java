package com.noori.pojos;

public class DirectSupervisor extends Employee {

	public DirectSupervisor(String username, String password, String newEmail, Double availableReimbursement) {
		super(username, password, newEmail, availableReimbursement);
		this.setWelcomeScreen("adminWelcome.html");
		this.setType("Direct Supervisor");
	}


	

}
