package com.noori.services;

import java.util.List;

import com.noori.daos.EmployeeDao;
import com.noori.daos.RequestDao;
import com.noori.daos.RequestDaoImpl;
import com.noori.pojos.Employee;
import com.noori.pojos.Request;

public class RequestService {
	private RequestDao rdi = new RequestDaoImpl();
	
	public Double newForm(Employee emp, Request req) {
		double projectedReimbursement = rdi.makeNewRequest(emp, req);
		return projectedReimbursement;
	}
	
	public int approve(Employee emp, Integer rid) {
		int boolInt = rdi.approveRequest(emp, rid);
		return boolInt;
		
	}
	
	public List personalRequests(Employee emp) {
		String sql = "select request.rid, request.name, request.start_time, request.end_time, request.descripton," + 
				" request.justification, request.cost, request.projected_reimbursement, request.location, " + 
				"	request.escalation_level, request_type.type, grading_format.format, request.grading_cutoff" + 
				"	from request " + 
				"		inner join request_type on request.rtid = request_type.rtid" + 
				"		inner join grading_format on request.gfid = grading_format.gfid";
			//	"	and eid = (select eid from employee where username = ? and pass = ?);";
		
		
		
		switch (emp.getType()) {
		case "Employee":
			System.out.println("yes this is");
			sql += "	and eid = (select eid from employee where username = ? and pass = ?);";
			
			break;
		case "Direct Supervisor":
			sql += "	and dsid = (select dsid from direct_supervisor where username = ? and pass = ?);";
			
			break;
		case "Department Head" :
			sql = sql + "	and dhid = (select dhid from department_head where username = ? and pass = ?);";
			
			break;
		case "Benefits Coordinator" :
			sql += "	and bcid = (select bid from benefits_coordinator where username = ? and pass = ?);";
			
			break;
		default:
			break;
		}
		
		List list = rdi.getPersonalRequestsMade(emp, sql);
		return list;
	}
	
	
	public List<Request> requestsToApprove(Employee emp) {
		List list;
		
		switch (emp.getType()) {
		case "Employee":
			return null;
		case "Direct Supervisor":
			list = rdi.getDSRequests(emp);
			return list;
		case "Department Head" :
			list = rdi.getDHRequests(emp);
			return list;
		case "Benefits Coordinator" :
			list = rdi.getBCRequests(emp);
			return list;
		default:
			break;
		}
		return null;
		
	}
	

}
